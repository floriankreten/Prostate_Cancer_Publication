#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Sep 25 10:49:10 2019

@author: floriankreten
"""


""" Not used atm/DEPRECATED
    Functions for showing the mutational patterns / relative frequencies
    The infamous 1/f-hypothesis for neutral evolution can be tested
    call pattern_plot for an impression and complete evaluation
"""

import plotly.offline as py
import plotly.graph_objs as go

from sklearn.linear_model import LinearRegression
import numpy as np

import PROCESS_structures
import EVAL_data_output
import EVAL_gen_tree_prep

    

def linear_interpol_privates(inv_freqs, border):
    """ Linear Interpolation and R^2 - fit  for different resolutions """
    
    private_inv_freqs = [ freq for freq in inv_freqs if freq >= border]
    X =  [border] + private_inv_freqs 
    Y =  [ i for i in range(len(X)) ] 
    
    # reshape input for the LinearRegression Function
    # shift x to start in 0, fix (0,0) as first point for regression
    x = np.array ([  i-X[0] for i in X])
    y = np.array ( [  i for i in Y] )
    x = x.reshape(-1,1)
    y = y.reshape(-1,1)
    
    #linear regression L with fit R
    reg = LinearRegression(fit_intercept=False).fit(x, y)
    R = round ( reg.score(x, y),3 )
    
    L = reg.predict(x)
    L = np.round(L,2)
    
    return L, Y, X, R

##############################################################

def read_pattern(some_cells, bin_size, inv_size, f_min):
    """ IN: either entire graph or array of biopsies
        OUT: array of 1/f boxes with resolution 0.1 """
    
    # size of boxes in % (maximum 100 corresponds to one box for 1/f-plot )
    
    """ Read INPUT / Shape input to right form """
    if isinstance(some_cells,  PROCESS_structures.graph):
        #input is a valid graph
        G = some_cells
    
    # if not: create graph-class for same handling
    elif type( some_cells ) == set:
        v = some_cells.pop()
        some_cells.add(v)
        if type(v) == PROCESS_structures.vertex:
            some_cells = list ( some_cells )
            G = PROCESS_structures.graph(2,4)
            G.V = G.V + some_cells
            G.count = len(some_cells)
    
    elif type (some_cells ) == list:
        if type(some_cells[0]) == PROCESS_structures.vertex:
            G = PROCESS_structures.graph(2,4)
            G.V = G.V + some_cells
            G.count = len(some_cells)
        else:
            print(type(some_cells[0]))
            raise ValueError("read_pattern got wrong input", type(some_cells))            
    
    # if not: cannot use input-type, raise error
    else:
        print(type(some_cells))
        raise ValueError("read_pattern got wrong input", type(some_cells))
    
        
    tumour, ANC, generations, branch_weight, centroids = \
            EVAL_gen_tree_prep.preparations(G)
    
    ##################################
    # we get the 1/f boxes by 2 parts:
    
    # 1) all mutations up to the MRCA are public (f=1), just look at ANC
    num_of_public_mutations = ANC
    
    # 2) all other mutations have branch_weights ~ relative frequencies
    total_frequences = [ branch_weight[key] for key in branch_weight if len(key) > ANC ]
    
    # add public mutations (frequency = 100%)
    for i in range(num_of_public_mutations):
        total_frequences.append(G.count)

    # sort branch_weights in descending order    
    total_frequences.sort(reverse=True)
    
    # get relative frequences
    total_weight = float(G.count)
    frequences = [ weight/total_weight for weight in total_frequences ]
    frequences = [ freq for freq in frequences if freq >= f_min ]
                
    # get inverse frequencies
    frequences_inv = [ 1.0 / freq for freq in frequences ]
                
    
    return frequences, frequences_inv


def create_bins(frequences, f_min, bin_size):
    L = 1 - f_min
    num_of_bins = int( L / bin_size + 1 )
    X = np.linspace(f_min, 1, num= num_of_bins)
    stepsize = (X[1] - X[0])*0.95
    Y_bins = []
    for x in X:
        arr = [freq for freq in frequences if abs(freq-x) <= stepsize ]
        yx = len( arr )
        Y_bins.append(yx)
    X_new = [ x*100 for x in X ]
    
    return X_new, Y_bins
    


def pattern_plot(file_name, input_name, some_cells):
    """ INPUT: file_name, input_name (of extracted cells),
        collection of cells, min_frequence,
        border-value between privates/publics"""
   
    # parameters for range, border priv/public and precision of bins
    bin_size = 0.02
    inv_size = 1
    
    f_min = 0.02
    priv_border_f = 0.35
    
    # get bins, values and accumulated values
    frequences_0, frequences_inv = read_pattern(some_cells, bin_size, inv_size, f_min)
    
    
    ################################################################
    # Plot the number of mutations against the frequency as bar-plot
    
    X, bins = create_bins(frequences_0, f_min, bin_size)
    
    bars = go.Bar(  x=X,
                    y=bins,
                    name = "mutations" )
    
    # prepare directory and filename
    fileDir = EVAL_data_output.create_folder(file_name, "mut_pattern_eval")
    filename = fileDir + "/" + input_name
    
    xaxis = dict( range = [0,100] )
    yaxis = dict ( range = [0, max(height for height in bins)] )

    layout = dict(height=900,
                       width=1200,
                 scene=dict(
                 xaxis=xaxis,
                 yaxis=yaxis,
                     ),
                 title = "Mutation pattern"
                )
    
    figure = {'data': [bars], "layout": layout }
    py.plot(figure, filename= filename + "_pattern.html",auto_open=False)
    
    
    ################################################################
    # R^2 - fit of the accumulated "private" mutations (low-frequency)
    # here, the x-axis is changed to 1/f
    border = 1.0/priv_border_f
    
    private_inv_freqs = [ freq for freq in frequences_inv if freq >= border]
    lin_interp, acc, xint, R = linear_interpol_privates(private_inv_freqs, border)
    
    private_interpol = go.Scatter(
            x= xint,
            y = lin_interp,
            mode = "lines",
            name = "Interpolation with fit " + str(R)
            )
    
    print("R-fit {}:".format(input_name), R)

    private_acc = go.Scatter(
            x=xint,
            y=acc,
            mode='lines',
            name = "private mutations accumulated"
            )

    layout = dict( height=900, width=1200,\
         title="R-sq fit of mutations with small frequency "\
             +str(priv_border_f) + " - " + str(f_min) )
    
    # prepare directory and filename
    fileDir = EVAL_data_output.create_folder(file_name, "mut_pattern_eval")
    filename = fileDir + "/" + input_name
    figure = {'data': [private_acc, private_interpol], "layout": layout }
    py.plot(figure, filename= filename + "_fit.html",auto_open=False)
    
    return R