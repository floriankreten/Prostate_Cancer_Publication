#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Feb  9 15:47:47 2023

@author: floriankreten
"""
import plotly.express as px
import pandas as pd
import plotly.offline as py


def VAF_plot(dir_name, num_bins = 50):
    """ IN: name of directory
        within this directory, an excel "all_mutations.xlsx" must exist
        reads info from this excel
        OUT: stores a VAF plot within this directory
    """
    
    data = pd.read_excel(dir_name + "/all_mutations.xlsx")
    
    figure = create_bins(data, num_bins)
    
    plot_name = str ( dir_name + "/" + "VAF_plot.html" )
    py.plot(figure, filename = plot_name, auto_open=False)
    
def create_bins(dataframe, num_bins=50, zero_cutoff = 0.005):
    
    percent_points = [ p for p in dataframe["Percent"][:50] if  p >= zero_cutoff ]
    
    bins = [ 0 for k in range(num_bins) ]
    bin_length = float(100.0 / num_bins)
    bin_points = [ bin_length/2.0 + k*bin_length for k in range(num_bins) ]
    
    def bin_num(perc):
        if perc == 100:
            return num_bins-1
        return int ( perc/bin_length  )
    
    for perc in percent_points:
        bins[ bin_num(perc)  ] +=1
        
    d = { "binned_point": bin_points, "number_of_mutations": bins  }
    df = pd.DataFrame(data = d)
    
    
    fig = px.bar(df, x='binned_point', y='number_of_mutations', height=400, title= "VAF-binned with bin-size " + str( round(bin_length,2) ))
    
    return fig
