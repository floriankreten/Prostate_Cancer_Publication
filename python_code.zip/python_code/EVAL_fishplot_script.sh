#!/bin/bash

# Fishplots are made in two steps: Data is extracted from python,
# then passed to R where it is plotted

python3 ./EVAL_fishplot_communication_python.py --filedir="path_to_tumor_folder"

Rscript ./EVAL_fishplot_communication_R.R "outout_name"

wait

echo all processes complete
