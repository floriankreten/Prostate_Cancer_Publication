﻿""" Testet with Python 3.7.13
    Requires one non-standard package: plotly (tested with 5.9.0) """

For a ready-to-use example with graphical output, run the prepared main.py.


The modules are sorted into 3 different groups:

1) PROCESS-modules are relevant for the simulations
2) EVAL-modules concern graphical output, storage and evaluations
3) Via INPUT_rates, the entire behavior of a simulation can be defined.
    All processes should be executed via the main-file.
	Include INPUT_rates first into the main and define a type-of-rate (see example).
	When changing the rates later, we recommend to start a new instance.


The graph-class defined in PROCESS_structures is the central object.
It is a collection of vertices and some structures/information.
A vertex is a structure that contains all infos about a vertex:
    position (in R^3), neighbors connected via edges, current genotype, rates of process at v

The graph changes via a sequence of random events. At the moment, three events are implemented:
PROCESS_growth, PROCESS_mutation, PROCESS_competition (PROCESS_radial_growth is not tested but runs)

The Gillespie-simulation is implemented in PROCESS_process. It refers to the PROCESS_event_manager
for the sampling of the next random event. I recommend to leave the last module at peace.


All evaluation-modules are bundled into the EVAL_single_graph_evaluation module.
The central object here is called "table_of_evaluation". After loading a graph into this table,
you can evaluate it in all possible senses and produce some graphical output (via plotly and matplotlib)


One routine is excluded currently from the "table_of_evaluation":
	For producing fishplots, you need a running version of R and the R-fishplot-module installed.
	The necessary communication between python and R is done via a data-format called feather.
	The shell-script EVAL_fishplot_script.sh does what is necessary to read in a
	complete history of a graph at a specific location and packs the feathers feathers.
	Take a look at https://github.com/chrisamiller/fishplot/tree/master/R for further instructions.
For taking and evaluating the biopsies, use "biopsy_evaluation_table" in EVAL_single_graph_evaluation.


The data IN/OUT is handled via the EVAL_data_output module. Graphs and ancestral trees can be stored
as SQL-databases. For working with stored data again,
I recommend to use the get_graph and get_tree functions from EVAL_data_output. Those handle
all the parsing and return useful objects.


For an example of how the modules work together and for more detailed evaluations,
we recommend running the following script:

# define behavior
import INPUT_rates
INPUT_rates.parameters["type_of_rate"] = "Effective_mutations"
INPUT_rates._set_rates()
    
evalsteps = [i * 10000 for i in [1,2,3,4,5,6,8,10,13,16,20] ]
filename = "output/test_simulation"
    
# run sim
import PROCESS_large_run_operations
G = PROCESS_large_run_operations.large_run(filename, evalsteps)

