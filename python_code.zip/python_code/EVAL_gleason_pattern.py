#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Nov  6 14:56:35 2019

@author: floriankreten
"""

""" Experimantel, not used atm:
    
    Evaluates the gleason patterns of a 2-dimensional slice
    of a virtual tumour, at best at different time stages """

    
"""  By default, the fitness of the vertex-points is evaluated
     This corresponds to the Gleason-Score only in the case without competition
     Hence use the specified Rate-scheme "gleason_type_evol: active tips only" """


import plotly.offline as py
import plotly.graph_objs as go
    
import EVAL_data_output
import INPUT_rates
import PROCESS_process

def make_frames(point_values):
    """ creates frames for plotly-plot """
    frames = []
    for point in point_values.keys():
        # Make a frame for each time-step
        # Get data
        data = point_values(point)
        # Add data to the frame
        frame = {'data': data, 'name': str(point)}
        frames.append(frame)
    return frames


class small_box:
    """ Small class, used as subclass within the 2d-container
        stores values collected in a certain region of the grid/2d-plane"""
    
    __slots__ = ["values", "position", "mean", "V", "B", "ratio"] #"val_range" ]
    
    def __init__(self, position):
        self.values = []
        self.position = position
        self.mean = None
        #self.val_range = None
        self.V = None
        self.B = None
        self.ratio = None
    
    def insert(self,value):
        self.values.append(value)
    
    # evaluation
    """
    old form
    def box_mean(self):
        L = len(self.values)
        if L != 0:
            val = sum(val for val in self.values) / float(L)
        else:
            val = 0
        self.mean = round(val,2)
        
    def box_val_range(self):
        MIN = min((val for val in self.values), default = 0)
        MAX = max((val for val in self.values), default = 0)
        self.val_range = (MIN, MAX)
       
    
    def eval_box(self):
        self.box_mean()
        self.box_val_range()
        return self.mean, self.val_range
    """
    def get_box_branchings(self):
        # total number of points
        V = len(self.values)
        # number of branched points
        B = len( [v for v in self.values if v==2] )
        self.V = V
        self.B = B
        self.ratio = None
        if self.V > 0:
            self.ratio = round ( float(self.B) / float(self.V) , 2)
        #return V, B
    

class dim2_container:
    """ 2d-grid used to store values (i.e. for gleason patterns)
        default: sets a """
    def __init__(self, box_length, max_coord, ver_size, ver_mid_point):
        # basic parameters
        self.z_size = ver_size/2.0
        self.max_coord = int(max_coord) + 1
        self.box_length = int(box_length)
        self.grid_len = int( 2 * self.max_coord / float(self.box_length) + 1)
        self.shift = int( self.max_coord / float(self.box_length) )
        self.grid = []
        self.z_height = ver_mid_point
        self.key = None
        
        # creating small boxes on the grid
        for i in range(self.grid_len):
            array = []
            for j in range(self.grid_len):
                pos = (-self.max_coord + self.box_length * i,
                       -self.max_coord + self.box_length * j)
                b = small_box( pos )
                array.append(b)
            self.grid.append(array)
            
        # for iterating over the boxes, see iter/next below
        self.index = [0,-1]

    def __getitem__(self, xy):
        x,y = xy
        return self.grid[x][y]
    
    def __iter__(self):
        return self
    
    def __next__(self):
        # move cursor when a row is finished
        if self.index[1] == self.grid_len-1:
            self.index[1] = -1
            self.index[0] += 1
        # end when done
        if self.index[0] == self.grid_len:
            self.index = [0,-1]
            raise StopIteration
            
        self.index = [self.index[0], self.index[1]+1]
        return self[self.index[0], self.index[1]]
    
    ##############################
    ########## EVALUATION ########
    
    """
    def VERTEX_check_insert_len_v_trait(self,v):
        x,y,z = v.position[0], v.position[1], v.position[2]
        # check if the point is in the right z-region
        if abs( z - self.z_height ) > self.z_size:
            return
        else:
            # find the right box and insert, shifted by grid_len (non-neg val)
            x_box = int(round(divmod(x, self.box_length) [0]))
            y_box = int(round(divmod(y, self.box_length) [0]))
            self.grid[x_box+self.shift][y_box+self.shift].insert(len(v.trait))
    """
            
    def VERTEX_check_insert_branch(self,v):
        x,y,z = v.position[0], v.position[1], v.position[2]
        # check if the point is in the right z-region
        if abs( z - self.z_height ) > self.z_size:
            return
        else:
            # find the right box and insert, shifted by grid_len (non-neg val)
            x_box = int(round(divmod(x, self.box_length) [0]))
            y_box = int(round(divmod(y, self.box_length) [0]))
            num_edges = bool ( v.out_edge_1) + bool ( v.out_edge_2 )
            self.grid[x_box+self.shift][y_box+self.shift].insert(num_edges)
            
    def insert_eval_graph(self, G):
        for v in G.V[1:]:
            self.VERTEX_check_insert_branch(v)
            # self.VERTEX_check_insert_len_v_trait(v) old version
            
    def eval_grid(self):
        for box in self:
            box.get_box_branchings()
            #box.eval_box()
             

def get_gleason_grid(G, box_length, ver_size, ver_mid_point):
    """ In: Graph G, desired resolution, maximal coordinate
        Out: Data for a plotly_plot """
    max_coord_x = max( v.position[0] for v in G.V[1:] )
    max_coord_y = max( v.position[1] for v in G.V[1:] )
    max_coord = max(max_coord_x, max_coord_y) + box_length
    grid = dim2_container(box_length, max_coord, ver_size, ver_mid_point)
    grid.insert_eval_graph(G)
    grid.eval_grid()
    grid.key = G.count
    return grid


def grid_to_frame(grid, frame_name, *databound):
    """ takes a grid and generates plotly-data, (for later plotting)
        databound: upper and lower bound for values (for fixing the colour-range)
        (needed if multiple frames from different sources shall be comparable"""
    
    x = [box.position[0] for box in grid if box.mean != 0]
    y = [box.position[1] for box in grid if box.mean != 0]
    values = [box.VB[0] / box.VB[1] for box in grid if box.mean != 0]
    
    text = [ "mean: " + str(box.mean) +\
            " | range: " + str(box.val_range) +\
            " | density: " + str(len(box.values)) for box in grid if box.mean != 0]
    
    if databound:
        databound = databound[0]
        if len(databound) != 2:
            raise ValueError("Plot Colour-Bound not correct: (Min, Max)")
        dots = go.Heatmap(x = x, y = y, z = values,
            hoverinfo = 'text',
            text = text,
            colorscale = 'Jet',
            name= frame_name,
            zmin = databound[0],
            zmax = databound[1]
            )
    
    else:
        dots = go.Heatmap(x = x, y = y, z = values,
            hoverinfo = 'text',
            text = text,
            name= frame_name,
            colorscale = 'Jet'
            )
        
    frame = dots
    return frame

def new_grid_to_frame(grid, frame_name, *databound):
    """ takes a grid and generates plotly-data, (for later plotting)
        databound: upper and lower bound for values (for fixing the colour-range)
        (needed if multiple frames from different sources shall be comparable"""
    
    
    # minimal density of a box that is evaluated
    box_lower_bound = 50
    x = [box.position[0] for box in grid if box.V > box_lower_bound ]
    y = [box.position[1] for box in grid if box.V > box_lower_bound]
    values_V = [ box.V for box in grid if box.V > box_lower_bound]
    values_ratio = [ box.ratio for box in grid if box.V > box_lower_bound]
    
    text = [ "rel-branching: " + str(values_ratio[i]) \
        + " | density: " + str(values_V[i]) for i in range(len(values_V)) ]
    
    if databound:
        databound = databound[0]
        if len(databound) != 2:
            raise ValueError("Plot Colour-Bound not correct: (Min, Max)")
        dots = go.Heatmap(x = x, y = y, z = values_ratio,
            hoverinfo = 'text',
            text = text,
            colorscale = 'Jet',
            name= frame_name,
            zmin = databound[0],
            zmax = databound[1]
            )
    
    else:
        dots = go.Heatmap(x = x, y = y, z = values_ratio,
            hoverinfo = 'text',
            text = text,
            name= frame_name,
            colorscale = 'Jet'
            )
        
    frame = dots
    return frame
    
def plot_single_grid_frame(frame, filename):
    figure = {'data': [], 'layout': {}}
    figure["data"] = [frame]

    layout = dict(height=900,
                 width=900,
                 hovermode = 'closest',
                 title = "Relative branching frequency"
                )

    figure['layout'] = layout
    dirname = EVAL_data_output.create_folder(filename, "single_eval")
    py.plot(figure, filename = dirname + "/sth.html")


def single_graph_gleason_eval(G, box_length, ver_size, ver_mid_point, filename):
    grid = get_gleason_grid(G, box_length, ver_size, ver_mid_point)
    frame = new_grid_to_frame( grid, \
                          "Size " + str(int(G.count/1000)) + " k" )
    plot_single_grid_frame(frame, filename)
    

#####################################################
#####################################################
    

def multiple_frames_plot(grids, frame_names, filename):
    """ IN: Several grids (i.e. from different time-points)
        OUT: Combined plot """
    
    MIN = []
    MAX = []
    
    # minimal density of a box that is evaluated
    box_lower_bound = 50
    for grid in grids:
        MIN.append( min(box.ratio for box in grid if box.V > box_lower_bound) )
        MAX.append( max(box.ratio for box in grid if box.V > box_lower_bound) )
    data_range = [ min( m for m in MIN), max(m for m in MAX) ]
    
    # make plotly-frames
    if len(grids) != len(frame_names):
        return ValueError("Len(grids) != len(frame_names)")
    frames = []
    for i in range(len(grids)):
        #frame = grid_to_frame(grids[i], frame_names[i], data_range)
        frame = new_grid_to_frame(grids[i], frame_names[i], data_range)
        frames.append(frame)
    
    fig = go.Figure()
    
    # add frames to figure, set visible = False as default
    for frame in frames:
        fig.add_trace(frame)
    for data in fig.data:
        data.visible = False

    # Make first trace visible (visible when opening figure)
    fig.data[0].visible = True
    
    # Create and add slider
    steps = []
    for i in range(len(fig.data)):
        step = dict(
            method="restyle",
            args=["visible", [False] * len(fig.data)],
            label = fig.data[i]["name"]
        )
        step["args"][1][i] = True  # make i'th trace "visible"
        steps.append(step)
    
    sliders = [ dict(  active=0,  steps=steps ) ]
    
    # layout: setup axis and plot size
    """
    x_axis=dict(  range = axis_range,
                  autorange=False
                  )
    y_axis=dict(  range = axis_range,
                  autorange=False
                  )
    scene=dict(xaxis=x_axis, yaxis=y_axis) """
    
    layout = dict(   height=900,
                     width=900,
                     hovermode = 'closest',
                     title = "Relative branching frequency",
                     sliders = sliders,
                     #scene = scene
                     )
    
    for key in layout.keys():
        fig.layout[key] = layout[key]
    dirname = EVAL_data_output.create_folder(filename)
    py.plot(fig, filename = dirname + "/Gleason-grading.html")
    return
    
#####################################################
#####################################################

def gleason_over_time(box_length, ver_size, ver_mid_point, eval_sizes,\
                      max_spatial_coordinate, filename):
    """ Runs a simulation and evaluates the resulting gleason-grading
        IN: parameters specifying the cuts (first line)
            estimate maximal tumour-size manually: be generous!(second line)
        OUT: Gleason-grading of the same region for different times"""
    
    # preparation
    frame_names = ["Size " + str(int(eval_size/1000)) + " k" \
                   for eval_size in eval_sizes]
    grids = []
    #first step: Setting up graph and running up to first eval_point
    G = PROCESS_process.produce_test_graph(
            border = eval_sizes[0], spatial_size = max_spatial_coordinate,
            key = "size", parameters = INPUT_rates.parameters)
    grids.append(get_gleason_grid( G=G, box_length = box_length,\
                    ver_size = ver_size, ver_mid_point = ver_mid_point))
    
    # continue simulation and add data-points
    for step in eval_sizes[1:]:
        G = PROCESS_process.continue_simulation(G=G, border = step, key = "size")
        grids.append(get_gleason_grid( G=G, box_length = box_length,\
                    ver_size = ver_size, ver_mid_point = ver_mid_point))
        
    # make plot
    multiple_frames_plot(grids, frame_names, filename)
    return G