#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jun 24 11:11:15 2019

@author: floriankreten
"""

""" Preferably use this module via EVAL_single_graph_evaluation """

""" evaluates a graph by using a gen_tree_graph and creates a
    3d map of the different clones
    classify nodes produces an input for a subset-plot (see graph_plot_plotly) """

import EVAL_gen_tree_graph
import plotly.offline as py
import plotly.graph_objs as go


import EVAL_data_output
import EVAL_gen_tree_reduced

import statistics

#%%
def classify_nodes ( G, find_size, find_type):
    """ Creates a tree with min_size find_size
        Clusters this tree
        Classifies the vertices of the graph """
    tree = EVAL_gen_tree_graph.create_gen_graph(G, find_size, find_type)
    tree.branch_based_cluster()
    tree.set_colours()
    
    G, group_list, tree = normal_classification_routine(G,tree)
                
    return G, group_list, tree


def classify_nodes_from_directory(G, dirname, find_size, find_type="absolute",
                                  cluster_type = "branch_based"):
    """ Reads in a stored tree from a given directory
        Transforms this into a rough tree
        Clusters are defined as living traits
        Classifies vertices of the graph """
        
    tree = EVAL_data_output.get_tree_sql(dirname, fullpathname=True)
    
    tree = EVAL_gen_tree_reduced.tree_reduction(tree, big_border=find_size,
                                                small_border=find_size,
                       str_out = False, size = find_type)
    
    if cluster_type == "branch_based":
        tree.branch_based_cluster()
        tree.set_colours()
        G, group_list, tree = normal_classification_routine(G,tree)
    
    elif cluster_type == "rough":
        tree.rough_cluster()
        tree.set_colours()
        G, group_list, tree = rough_classification_routine(G,tree)
        
    else:
        raise ValueError("cluster-type undefined")
                
    return G, group_list, tree
        
    
#%%
def rough_classification_routine(G, tree):
    """ Takes a graph G and a rough tree (with set colours)
        OUT: G, group_list, tree
        Vertices of the graph are classified via traits of the rough tree """
        
    # needs to go through types in specific ordering
    # this is ok since the set is in fact a sorted set
    cluster_nodes = tree.group_points
    group_list = tuple(node.name for node in cluster_nodes)
    unc = "unclassified"
    
    for v in G.V[1:]:
        v.cluster_group = unc
        for i in range(len(group_list)):
            trait = group_list[i]
            K = len(trait)
            if K < len(v.trait):
                comparison = v.trait[:K]
            elif K == len(v.trait):
                comparison = v.trait
            else:
                comparison = False
            if comparison == trait:
                v.cluster_group = i
                break
                
    return G, group_list, tree
                

def normal_classification_routine(G,tree):
    """ Takes a graph G and a branched tree (with set colours)
        OUT: G, group_list, tree and vertices of the graph are classified """
    cluster_nodes = tree.group_points
    group_list = tuple(node.name for node in cluster_nodes)
    unc = "unclassified"
    
    for v in G.V[1:]:
        v.cluster_group = unc

    MAX, MIN = max ( len(n) for n in group_list), min(len(n) for n in group_list)
    

    generations = [ {} for s in range(MAX+1)]
    for i in range(len(group_list)):
        trait = group_list[i]
        K = len(trait)
        generations[K][trait] = i


    for v in G.V[1:]:
        trait = v.trait
        K = len(trait)
        V = min(K, MAX)
        stop = False
        # assigns a group to the vertex if possible
        for comparison_level in range(MIN, V+1, 1):
            levelset = generations[comparison_level]
            comparison = trait[:comparison_level]
            # if the node is part of the group:
            for gen in levelset:
                if gen == comparison:
                    v.cluster_group = levelset[gen]
                    stop = True
                    break
            if stop:
                break
                
    return G, group_list, tree
    
#%%
# plot of clonal centers (in space)
# quite independent from the above stuff
def clonal_centers_plot(tree, file_name, show = False):
    """ plots the weighted centers of each type
        either you give the function a gen_tree or it creates one """
    
    # preparations
    if tree.group_points == None:
        tree.branch_based_cluster()
        
    # check arbitrary element from the points for colour 
    for point in tree.group_points:
        if point.colour == None:
            tree.set_colours()
            break
    
    point_list = list ( tree.group_points )
    
    xV = [ v.spatial_center[0] for v in point_list  ]
    yV = [ v.spatial_center[1] for v in point_list  ]
    zV = [ v.spatial_center[2] for v in point_list  ]
    
    sizes = [ float(v.branch_weight/tree.root.branch_weight) for v in tree.group_points]
    mean_size_scale = 1.0 / statistics.median(sizes)
    sizes = [ 15 * float(size) * mean_size_scale for size in sizes]
    
    
    # plot
    labels = []
    for v in point_list:
        rel_weight = round ( v.branch_weight /tree.total_weight *100,2)
        
        M = v.max_fitness
                
             
        labels.append ( str("Size:  " + str ( rel_weight ) +"%" +\
                                        " | Type:  " + str( v.name ) + \
                                " | Maximal fitness:  " + str( round (M, 2))
                                ) )
        

    colours = list ( v.colour for v in point_list )
        
        
    vertices = go.Scatter3d(x=xV,
        y=yV,
        z=zV,
        text=labels,
        hoverinfo = 'text',
        mode = 'markers',
        marker=dict(
            sizemode='diameter',
            # size = 5,
            size = sizes,
            color = colours,
            colorscale = 'Jet',
            cmin = 0,
            cmax = 1,
            opacity = 0.1
        )
    )
        
    
    dots = go.Scatter3d(x=xV,   #is a debug for opacity =1
        y=yV,
        z=zV,
        hoverinfo = 'none',
        mode = 'markers',
        marker=dict(
            sizemode='diameter',
            # size = 5,
            size = sizes,
            color = colours,
            colorscale = 'Jet',
            cmin = 0,
            cmax = 1,
            opacity = 1
        )
    )
        
    camera = dict(
        up=dict(x=0, y=0, z=1),
        center=dict(x=0, y=0, z=0),
        eye=dict(x=1.5, y=1.5, z=1.5) )
        
    noaxis=dict(visible = False,
                showbackground=False,
              showline=False,
              zeroline=False,
              showgrid=False,
              showticklabels=False
              )

    layout = dict(height=900,
                       width=900,
                       showlegend=False,
                 scene=dict(
                 xaxis=noaxis,
                 yaxis=noaxis,
                 zaxis=noaxis,
                 camera=camera
                     ),
                         hovermode = "closest"
                 )

    figure = go.Figure(data = [vertices, dots], layout = layout)  
    
    # Creates directory for storage
    dirName = EVAL_data_output.create_folder(file_name)
    print("   Plotting clonal centers")
    name = str ( dirName + "/" + "clonal_centers.html" )
    py.plot(figure, filename = name, auto_open=show)
    
    return