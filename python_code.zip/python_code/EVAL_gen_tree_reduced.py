#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jul 28 14:47:10 2020

@author: florian
"""

""" Preferably use this module via EVAL_single_graph_evaluation

    Used for creating the "rough"-trees", i.e. when extracting only the most
    important mutations in the upper part of an ancestral tree"""

import plotly.offline as py
import plotly.graph_objs as go

import EVAL_gen_tree_graph
import EVAL_data_output

from ordered_set import OrderedSet

class reduced_tree(EVAL_gen_tree_graph.ancestral_tree):
    """ INPUT: ancestral tree
        OUT: reduced tree and disjoints sets of vertices (for plot) """
        
    def __init__(self):
        self.big_border = None
        self.small_border = None
        
        self.big_branches = None
        self.big_green = None
        self.small_green = None
        self.grey = None
        self.white = None
        

    def reduced_plot(self):
        print("Reduced plot not done yet :S")
        print( self.V.keys() )
        
    def rough_cluster(self):
        """ All traits with positive weight are taken as cluster-nodes
            others get v.group = False """
        group_points = []
        
        for v in self.V.values():
            if v.weight > 0:
                group_points.append(v)
                v.group = v
            else:
                v.group = False
            
        # traits are stored in a sorted set
        # the ordering is important for classification later
        # long entries (advanced types) first, root last entry
        group_points.sort(key = lambda v: -len(v.name) )
        self.group_points = OrderedSet(group_points)

    
    def clonal_sketch(self, filename="test", title="", fullpathname = False):
        """ Sketches the important mutations of a tumor """
        
        big_green = [ self.V[v] for v in self.big_green ]
        small_green = [ self.V[v] for v in self.small_green]
        grey = [ self.V[v] for v in self.grey ]
        white = [ self.V[v] for v in self.white ]

        # COORDINATES OF NODES
        # step 1: get subtree-sizes
        subtree_size = {}
        for i in range ( self.height -1 , -1 , -1) :
            gen = self.generations[i]
            for v in gen:
                subtree_size[v] = max (
                        sum ( subtree_size[child] for child in v.children )
                        ,  1 )
                
        # step 2: assign x,y-values
        coordinates = {}
        root_position = 0   # common ancestor is placed in the center
        root = self.root
        
            
        #Finds position of the nodes, recursive node-placement
        #Definces coordinates-dictionary
        scale = 0.8
            
        def place_subtree(self, v, position, factor):
            """recursively sets position of nodes"""
            
            coordinates [v] = [ position, - len(v.name) ]
            
            if len(v.children) > 1:
                newfactor = factor * scale
            else:
                newfactor = factor
            left_border = position - newfactor * 0.5 * subtree_size[v]
            position = left_border
            
            for child in v.children:
                position += (subtree_size[child] * 0.5 * newfactor)
                place_subtree(self, child, position, factor)
                position += (subtree_size[child] * 0.5 * newfactor)
            
        place_subtree(self, root, root_position, 1)
        
        
        # find edge-positions for the tree 
        x_edges = []
        y_edges = []
        
        for v in self.V.values():
            start = coordinates[v]
            for child in v.children:
                end = coordinates[child]

                x_edges.append(start[0])
                x_edges.append(end[0])
                
                y_edges.append(start[1])
                y_edges.append(end[1])
                
                y_edges.append(None)
                x_edges.append(None)
        
        # strong mutations that are left in the small tree
        strong_mutations_found = self.V.keys() & self.strong_mutations_log.keys()
        
        def text_of_node(v):
            size = round(v.weight/self.root.branch_weight*100,2)
            name = v.name
            out = str(name)
            
            if name in strong_mutations_found:
                time = self.strong_mutations_log[name]
                out += " | time: " + str(int(time))
            
            if size > 0:
                out += " | size: " + str(size) + "%"
                
            return out 
        
        # add big green markers to indicate living traits
        big_green_x = [ coordinates [v][0] for v in big_green ]
        big_green_y = [ coordinates [v][1] for v in big_green ]
        big_green_info = [  text_of_node(v) for v in big_green]

        # small green markers for smaller traits
        small_green_x = [  coordinates [v][0] for v in small_green  ]
        small_green_y = [  coordinates [v][1] for v in small_green  ]
        small_green_info = [ text_of_node(v) for v in small_green ]
        
        # empty white dots for extinct types
        white_empty_x = [  coordinates [v][0] for v in white  ]
        white_empty_y = [  coordinates [v][1] for v in white  ]
        white_info = [ text_of_node(v) for v in white ]
        
        # grey dots for very small types
        grey_x = [  coordinates [v][0] for v in grey  ]
        grey_y = [  coordinates [v][1] for v in grey  ]
        grey_info = [ text_of_node(v) for v in grey ]
        
        # strong mutations
        strong_x = [  coordinates [ self.V[v] ][0] for v in strong_mutations_found  ]
        strong_y = [  coordinates [ self.V[v] ][1] for v in strong_mutations_found  ]

        
        ##########################
        #   PLOTTING VIA PLOTLY
        ##########################
        big_size = 60
        med_size = 30
        small_size = 10

        # black edges between coalescants
        edges           = go.Scatter(
                            x=x_edges,
                            y=y_edges,
                            mode='lines',
                            line=dict( color='black', width = 5),
                            name = "edges",
                            showlegend = False
                            )
        
        #  strong mutations
        strong_mut_dots   = go.Scatter (
                            x= strong_x,
                            y= strong_y,
                            mode = 'markers',
                            marker = dict(
                                size = small_size,
                                color = 'red',
                                ),
                            hoverinfo = 'none',
                            name = "Strong mutations"
                            )
        
        # big dots
        big_green_dots   = go.Scatter (
                            x= big_green_x,
                            y= big_green_y,
                            mode = 'markers',
                            marker = dict(
                                size = big_size,
                                color = 'darkgreen',
                                line=dict(
                                    color='black',
                                    width=5
                                )
                                ),
                            hoverinfo = 'text',
                            text = big_green_info,
                            name= "Size >= " + str(self.big_border)
                            )
        
        # small green dots
        small_green_dots = go.Scatter(
                            x= small_green_x,
                            y= small_green_y,
                            mode = 'markers',
                            marker = dict(
                                size  = med_size,
                                color = 'lawngreen',
                                line=dict(
                                    color='black',
                                    width=5
                                )
                            ),
                            hoverinfo = "text",
                            text = small_green_info,
                            name = ">= " + str(self.small_border),
                            )
        
        
        # grey dots
        grey_dots = go.Scatter(
                            x=grey_x,
                            y=grey_y,
                            mode='markers',
                            marker=dict(
                                size  = med_size,
                                color = 'grey',
                                line=dict(
                                    color='black',
                                    width=5
                                )
                            ),
                            hoverinfo = 'text',
                            text = grey_info,
                            name = "< " + str(self.small_border)
                        )
        
        # white dots
        white_dots = go.Scatter(
                            mode='markers',
                            x=white_empty_x,
                            y=white_empty_y,
                            marker=dict(
                                color='white',
                                size=med_size,
                                line=dict(
                                    color='black',
                                    width=5
                                )
                            ),
                            hoverinfo = 'text',
                            text = white_info,
                            name = "Extinct"
                        )
    
        
        # put things together to a plotly figure and print it
        figure = {'data': [], 'layout': {} }
        noaxis = dict           (
                            autorange=True,
                            showgrid=False,
                            zeroline=False,
                            showline=False,
                            ticks='',
                            showticklabels=False )

        layout = go.Layout( xaxis = noaxis, yaxis = noaxis, title=title,
                           hovermode = 'closest')
        
        figure['data']=[edges, big_green_dots, small_green_dots,
                        white_dots, grey_dots, strong_mut_dots]
            
        figure['layout']= layout
        
        # Creates directory for storage
        if not fullpathname:
            dirName = EVAL_data_output.create_folder(filename)
            name = str ( dirName + "/" + "anc_tree_rough.html" )
        else:
            name = filename

        py.plot(figure, filename = name, auto_open=False ) 
        return
    
    
#%%
# Preparation-steps for transferring big to small tree     
        
def tree_reduction(tree, big_border=0.1, small_border=0.05,
                   str_out = False, size = "relative"):
    
    
    big_branches, big_green, small_green, grey, white = \
        _get_hierarchy_sets(tree, big_border, small_border,
                            size = size, str_out = str_out)
    
    big_dict = {}
    for v in big_branches:
        big_dict[v] = tree[v]
    
    tree.reduce_tree(big_dict)
    tree.__class__ = reduced_tree
    
    tree.big_border =  big_border
    tree.small_border = small_border
        
    tree.big_branches = big_branches
    tree.big_green = big_green
    tree.small_green = small_green
    tree.grey = grey
    tree.white = white
    
    # TODO!!!
    
    print("old tree destroyed, new one done")
    return tree
    


def _get_hierarchy_sets(tree, big_border=1.0, small_border=0.05, size="relative", str_out = False): 
    # TODO: big_border = 0.1 was before
    """ Get hierarchy of important mutations
        Also rebalances the weights
        WARNING: Original tree gets messed up in the process """

    totw = tree.total_weight
    
    # Evaluate only upper part of tree
    if size == "relative":
        assert 1.0 >= big_border >= small_border >= 0
        big_branches = set ( v for v in tree.V if tree[v].branch_weight/totw >= small_border )
        # adjust weights
        for v in big_branches:
            lost_children = set (w.name for w in tree[v].children)
            lost_children.difference_update( big_branches )
            gain = sum ( tree[w].branch_weight for w in lost_children )
            tree[v].weight = tree[v].weight + gain
            
        big_living = set ( v for v in big_branches if tree[v].weight/totw >= big_border )
        medium_living = set (v for v in big_branches if big_border > tree[v].weight/totw >= small_border )
        small_living = set (v for v in big_branches if small_border > tree[v].weight/totw and tree[v].weight > 0 )
        extinct = set (v for v in big_branches if tree[v].weight == 0 )
            
    if size == "absolute":
        assert tree.total_weight >= big_border >= small_border >= 0
        big_branches = set ( v for v in tree.V if tree[v].branch_weight >= small_border )
        # adjust weights
        for v in big_branches:
            lost_children = set (w.name for w in tree[v].children)
            lost_children.difference_update( big_branches )
            gain = sum ( tree[w].branch_weight for w in lost_children )
            tree[v].weight = tree[v].weight + gain
        
    
        big_living = set ( v for v in big_branches if tree[v].weight >= big_border )
        medium_living = set (v for v in big_branches if big_border > tree[v].weight >= small_border )
        small_living = set (v for v in big_branches if small_border > tree[v].weight and tree[v].weight > 0 )
        extinct = set (v for v in big_branches if tree[v].weight == 0 )
    
    
    # Make resulting sets disjoint
    big_green = big_living
    
    small_green = medium_living
    small_green.difference_update(big_green)
    
    grey = small_living
    grey.difference_update(small_green, big_green)
    
    white = extinct
    white.difference_update(big_green, small_green, grey)
    
    if str_out:
        print("ALL", big_branches, "\n")
        print("BIG", big_green, "\n")
        print("MED", small_green, "\n")
        print("sml", grey, "\n")
        print("NO", white, "\n")
    
    return big_branches, big_green, small_green, grey, white

#%%

def abs_file_path_eval_rough_trees(absolute_directory):
    """ IN: File and directory
        OUT: 3 different rough-trees: borders (10,5)%, (5,0.5)%, (1, 0.1)% """
    
    # round 1
    big_border, small_border = 0.1, 0.05
    tree1 = EVAL_data_output.get_tree_sql(absolute_directory, fullpathname=True)
    tree1 = tree_reduction(tree1, big_border, small_border)
    name1 = absolute_directory + "/rough_tree_" + str(int(round(big_border*100,0))) + \
        "_" + str(int(round(small_border*100,0))) + ".html"
    tree1.clonal_sketch(filename=name1, fullpathname = True)
    
    # round 2 (warning: nameing not automatic!)
    big_border, small_border = 0.05, 0.005
    tree2 = EVAL_data_output.get_tree_sql(absolute_directory, fullpathname=True)
    tree2 = tree_reduction(tree2, big_border, small_border)
    name2 = absolute_directory + "/rough_tree_" + str(int(round(big_border*100,0))) + \
        "_" + "05" + ".html"
    tree2.clonal_sketch(filename=name2, fullpathname = True)
    
    # round 3
    big_border, small_border = 0.1, 0.01
    tree3 = EVAL_data_output.get_tree_sql(absolute_directory, fullpathname=True)
    tree3 = tree_reduction(tree2, big_border, small_border)
    name3 = absolute_directory + "/rough_tree_" + str(int(round(big_border*100,0))) + \
        "_" + str(int(round(small_border*100,0))) + ".html"
    tree3.clonal_sketch(filename=name3, fullpathname = True)