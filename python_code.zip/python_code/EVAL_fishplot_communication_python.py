#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jul 22 12:30:45 2020

@author: florian
"""

""" First part of the Fishplot: Extract data via Python and store them as feathers """

import EVAL_data_output
import pandas as pd 
import os
from pathlib import Path


def produce_fishplot_data(filedir, evalpoints, cutoffsize=0.02, growing = False):
    """ Read in a complete graph-directory and produce data for fishplots
        the evalpoints need to be specified manually, they reflect the
        evaluated subdirectories (=images of tumor at a certain size/time) """
    
    names = [ filedir + "/" + str(i) for i in evalpoints]
    
    trees = [  EVAL_data_output.get_tree_sql(filename, fullpathname=True) for filename in names]
    parameters = [ EVAL_data_output.get_graph_info(filename, True) for filename in names]
    
    # get time-points
    def get_time(p):
        spec_list = list (i for i in p["Specification"] )
        time_key = spec_list.index("time")
        time = p["Parameter"][time_key]
        return time
    
    times = [  get_time(p) for p in parameters]
    
    
    # make dict of all important mutations
    def checkup_routine(cutoff):
        count = 1
        types_to_ints = {}
        
        for tree in trees:
            tot_size = tree.total_weight
            
            for name,item in tree.V.items():
                rel_weight = item.branch_weight / tot_size

                if rel_weight >= cutoff:
                    if name not in types_to_ints:
                        types_to_ints[name] = count
                        count += 1
                        
        return types_to_ints
    
    # by default, fishplot can handle only 10 different types :S
    other_poss_sizes = [0.03, 0.04, 0.05, 0.06, 0.07, 0.08, 0.09, 0.10]
    i = 0

    types_to_ints = checkup_routine(cutoffsize)
    while len(types_to_ints) > 10:
        cutoffsize= other_poss_sizes[i]
        types_to_ints = checkup_routine(cutoffsize)
        i +=1
    if len(types_to_ints) > 10:
        raise ValueError("Fishplot only configured for 10 traits,\n \
                         failed for max cutoff-threshold", other_poss_sizes[-1],
                         "\nreduce input manually")
        

    # make parent-relation-table
    parents = [0 for i in range(len(types_to_ints)) ]
    
    for type_name,type_int in types_to_ints.items():
        if len(type_name) > 1:
            parent = tuple (type_name[0:-1])
            parent_number = types_to_ints[parent]
            parents[type_int-1] = parent_number
            
    # make size-arrays for different timepoints
    all_sizes = []
    
    for tree in trees:
        if not growing:
            tot_size = tree.total_weight
        else:
            tot_size = trees[-1].total_weight
        rel_sizes = [0.0 for i in range(len(types_to_ints)) ]
        # beware of index-shift in r!
        for name,index in types_to_ints.items():
            if name in tree.V:
                rel_weight = tree.V[name].branch_weight / tot_size
                rel_sizes[index-1] = round(100*rel_weight,2)
               
        # push child-size up to the top (can be done better...)
        for i in range(len(parents)):
            for type_name,type_int in types_to_ints.items():
                if len(type_name) > 1:
                    parent = tuple (type_name[0:-1])
                    parent_number = types_to_ints[parent]
                    parent_size = rel_sizes[parent_number-1]
                    child_size = rel_sizes[type_int-1]
                    
                    rel_sizes[parent_number-1] = max(parent_size,
                                                     child_size)
                else:
                    rel_sizes[type_int-1] = 100
                
        all_sizes += rel_sizes
            
    #print("Times:\n",times,"\n")
    #print("Sizes\n",all_sizes,"\n")
    #print("Parents",parents,"\n")
    return times, all_sizes, parents

def data_for_r(times, sizes, parents):
    directory = os.getcwd()
    dirName = str ( directory + "/featherdata"  )
    Path(dirName).mkdir(parents=True, exist_ok=True)
    
    Timedf = pd.DataFrame(times, columns = ["timepoints"])
    Timedf.to_feather(dirName + "/times.feather")
    
    sizedf = pd.DataFrame(sizes, columns = ["sizes"])
    sizedf.to_feather(dirName + "/sizes.feather")
    
    parentdf = pd.DataFrame(parents, columns = ["parents"])
    parentdf.to_feather(dirName + "/parents.feather")
    
def export_fishplot_data(filedir, evalpoints, cutoffsize=0.02, growing = False):
    times, all_sizes, parents = produce_fishplot_data(filedir, evalpoints, cutoffsize, growing)
    data_for_r(times, all_sizes, parents)
    print("Packing feathers complete")
  


if __name__ == "__main__":
    import argparse
    import sys
    assert sys.version_info >= (3, 6, 5)
    
    # specify the evaluated size/time points here !
    mio_points = [1,2,3,4,5,6,8,10,13,16,20]
    eval_points= [ str(i) + "Mio" for i in mio_points ]
    
    parser = argparse.ArgumentParser(description='PARSER for the inputname')
    parser.add_argument("--filedir", required = True, type = str, help="Filename of sim")
    args = parser.parse_args()
    
    filedir = args.filedir
    
    #filedir = "/home/florian/Dropbox/Prostatakarzinom_Kreten_Tolkach/Database_Simulations/20Mio_Mai_Juni/AKTUELL/_STR_MUT/2_strong_mutations_x50_mit_saturation/20Mio_y6"
    
    export_fishplot_data(filedir, eval_points, growing = True)
    
