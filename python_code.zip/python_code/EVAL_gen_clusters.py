#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Mar  6 11:18:05 2023

@author: floriankreten
"""

# Several (secondary) functions for summarizing statistics

import pandas as pd
import numpy as np
import json

from pathlib import Path

import plotly.offline as py
import plotly.graph_objs as go


def get_raw_ccf_values(filename, min_CCF = 2):
    """ Extract data from an all_mut_xls
        IN: complete file-path
        OUT: two arrays: names, CCFs """
    
    df = pd.read_excel(filename)
    cluster_names = []
    cluster_CCFs = []
    
    for row in df.iterrows():
        values = row[1]
        
        # filter for empty rows
        CCF = values[1]
        if not np.isnan(CCF):
            
            if CCF < min_CCF:
                break
            
            name = eval(values[8])
            cluster_names.append(name)
            cluster_CCFs.append(round(CCF,1))
        
    return cluster_names, cluster_CCFs


def names_are_lineage(name1, name2):
    """ Checks if name2 is a child of name1
            NOT symmetric w.r.t. input (for easier use in loop, see clean clusters)
        returns True if this is given """
        
    K1 = len(name1)
    K2 = len(name2)
    
    if ( K1 - K2 >=1 ):
        if (  tuple(name1[:K2]) == tuple(name2) ):
            return True
    else:
        return False


def clean_clusters(names, CCFs, perc_diff = 4.0):
    
    """ group clusters """
    removed = []
    for k in range ( len(names) ):
        for l in range(len(names)):
            if l != k:
                if np.abs ( CCFs[l] - CCFs[k] ) <= perc_diff:
                    #print("ABS FOUND", l, k)
                    if names_are_lineage(names[k], names[l]):
                        #print("LINEAGE ", l, k)
                        removed.append(k)
    removed = set(removed)
    removed = list(removed)
    removed.sort(reverse = True)

    for r in removed:
        del(names[r])
        del(CCFs[r])

    return names, CCFs

def get_cluster_CCFs(filename, perc_diff= 4.0):
    names, CCFs = get_raw_ccf_values(filename)
    names, CCFs = clean_clusters(names, CCFs, perc_diff)
    return names, CCFs

def get_all_biopsy_CCFs(dir_name,  perc_diff = 4.0):
    """ Loads the CCFs of the clusters (and their genotypes) into a dictionary """
    
    if dir_name.endswith("/"):
        b1 = dir_name + "4_quad_on_different_levels/"
        b2 = dir_name + "4_quad_on_same_level/"
    else:
        b1 = dir_name + "/4_quad_on_different_levels/"
        b2 = dir_name + "/4_quad_on_same_level/"
    
    cvalues1 = []
    cvalues2 = []
    
    nvalues1 = []
    nvalues2 = []
    
    
    for i in range(1,5):
        filename1 = b1 + "biopsy_" + str(i) + "/all_mutations.xlsx"
        filename2 = b2 + "biopsy_" + str(i) + "/all_mutations.xlsx"
        nval1, cval1 = get_cluster_CCFs(filename1, perc_diff)
        nval2, cval2 = get_cluster_CCFs(filename2, perc_diff)
        cvalues1.append(cval1)
        cvalues2.append(cval2)
        
        nvalues1.append(nval1)
        nvalues2.append(nval2)
    
    CCF = {}
    CCF["4_quad_on_different_levels"] = cvalues1
    CCF["4_quad_on_same_level"] = cvalues2
    
    Names = {}
    Names["4_quad_on_different_levels"] = nvalues1
    Names["4_quad_on_same_level"] = nvalues2
    
    return Names, CCF




def plot_gen_cluster_roaster(cluster_list, cluster_names_list, filename,
                             biopsy_type = "4_quad_on_different_levels",
                             cutoff = 5):
    
    C = len(cluster_list)
    L = len (cluster_list[0][biopsy_type])
    
    height = 5
    width = 15
    

    # produce a grid for the K cases
    x_edges = []
    y_edges = []
    
    # list of dots for the reported CCFs
    x_vertices = []
    y_vertices = []
    
    for i in range(1, L):
        A = np.array( [i*width,0]  )
        B = np.array( [i*width,-(C+1)*height]  )
        
        x_edges.append(A[0])
        x_edges.append(B[0])
                            
        y_edges.append(A[1])
        y_edges.append(B[1])
                            
        y_edges.append(None)
        x_edges.append(None)
        
    all_clusters = []
    perc_labels = []

    for i in range(1,C+1):
        # outer borders of the box for the i-th case study
        X00 = np.array( [0, -height* i]  )
        #X01 = X00 + np.array( [0, height]  )
        #X11 = X01 + np.array( [L*width,0 ] )
        X10 = X00 + np.array( [L*width, 0] )
        
        x_edges.append(X00[0])
        x_edges.append(X10[0])
                            
        y_edges.append(X00[1])
        y_edges.append(X10[1])
                            
        y_edges.append(None)
        x_edges.append(None)
        
        # Each Cluster gets a point (within the current box)
        # iterating over the (usually 4) biopsies
        
        #print(len(cluster_list[i][biopsy_type]))
        #"""
        for j in range(L):
            sample = cluster_list[i-1][biopsy_type][j]
            START = X00 +  np.array( [j*width, 0.5* height]  )
            for k in range(len(sample)):
                s = sample[k]
                if s < 100 and s >= cutoff:
                    X = START + np.array( [(s * width)/100.0, 0]  )
                    x_vertices.append(X[0])
                    y_vertices.append(X[1])
                    all_clusters.append(s)
                    
                    name = cluster_names_list[i-1][biopsy_type][j][k]
                    
                    perc_labels.append ( str(round(s,1)) + "% | " + str(tuple(name)) )
        
        


    edges = go.Scatter(     x=x_edges,
                            y=y_edges,
                            mode='lines',
                            #name='coalescence',
                            line=dict( color='black', width = 0.8),
                            hoverinfo='none'
                            )
    
    
    CCF_dots = go.Scatter (
            x = x_vertices,
            y = y_vertices,
            hoverinfo = 'text',
            text = perc_labels,
            #opacity = 0.99,
            mode = 'markers',
            name='Gen-cluster CCF in biopsy',
            marker = dict(size = 8, color = 'green' )
    )



    # put things together to a plotly figure and print it
    figure = {'data': [], 'layout': {} }
    noaxis = dict (autorange=True,
                   showgrid=False,
                   zeroline=False,
                   showline=False,
                   ticks='',
                   showticklabels=False )
    
    
    mean = round( np.mean(all_clusters),1)
    variance = round( np.std(all_clusters),1)
    
    num_clusters = round( float( len (all_clusters) ) / ( C * L ) ,1 )
    
    title = "Gen_Clusters with CCF in [" + str(cutoff) + ", 100) <br>"
    title = title + "Mean size of cluster: " + str(mean) + "% | STD: " + str(variance) + "%"
    title = title + " | Mean number of clusters: " + str(num_clusters) + " <br>"
    title = title + "Used biopsy type: " + biopsy_type

    layout = go.Layout( xaxis = noaxis, yaxis = noaxis, title=title,
                        hovermode = 'closest')
    
    figure['layout']= layout
    figure['data']=[edges, CCF_dots]

    # Creates directory for storage
    dirName = filename
    Path(dirName).mkdir(parents=True, exist_ok=True)
       
    if str(dirName).endswith("/"):
        name = str ( dirName + "gen_clusters_CCF.html" )
    else:
        name = str ( dirName + "/gen_clusters_CCF.html" )

    py.plot(figure, filename = name, auto_open=False ) 
    return

def plot_cluster_from_json(cluster_file, names_file, out_directory,
            biopsy_type = "4_quad_on_different_levels",
            cutoff = 5):
    
    with open(cluster_file , 'r') as read_file:
        CCF = json.load(read_file)
    with open(names_file , 'r') as read_file:
        names = json.load(read_file)
        
    plot_gen_cluster_roaster(CCF, names, out_directory, biopsy_type = biopsy_type)

        
#%%
############################################
# Statistics for subclonal populations
############################################

def show_summarizig_statistics_for_ccfs_in_biopsies(CCF, mut_speed = "x100"):
    """ Input: A name "mut_speed"
               A CCF dictionary of Cancer Cell Fraction, see above
        Output: (Visual) Summarizing statistics
    """

    cutoff_low = 5.0
    cutoff_high = 95.0
    
    num_tumors = len(CCF)
    num_biopsies = len (CCF[0]["4_quad_on_same_level"])
    
    clusters_in_biopsies = []
    all_clusters = []
    num_clusters = []

    for i in range(num_tumors):
        for j in range(num_biopsies):
            biopsy = CCF[i]["4_quad_on_same_level"][j]
            valid_clusters = [ g for g in biopsy if (g >= cutoff_low and g<= cutoff_high)]
            clusters_in_biopsies.append(valid_clusters)
            
            for v in valid_clusters:
                all_clusters.append(v)
            num_clusters.append( len(valid_clusters) )

    mean_n = round(np.mean(num_clusters),1)
    variance_n = round(np.std(num_clusters ),1)
    
    mean_c = round(np.mean(all_clusters),1)
    variance_c = round(np.std(all_clusters ),1)

    text = "Evaluated " + str(num_tumors) + " tumors(" + mut_speed +"), each with " + str(num_biopsies) + " flat biopsies on same level.\n"
    print(text)
    title = "Subclonal populations within range [ " + str(cutoff_low) + ", " + str(cutoff_high) + " ]"
    print(title)
    
    print("Number of clusters")
    print("   Mean: ", mean_n, " |Std: ", variance_n)
    
    print("CCF of clusters")
    print("   Mean: ", mean_c, " |Std: ", variance_c)
