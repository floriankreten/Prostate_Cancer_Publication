#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Nov 21 10:13:03 2018

@author: floriankreten
"""

""" Testet with Python 3.7.13
    Requires one non-standard package: plotly (tested with 5.9.0) """


""" Simplified setup for visualization:
        Small simulation with high rate of driver mutations
"""


# First step: define behavior via the rates-file
# Below you can adjust the two most relevant parameters
# You should start a new instance/reset the kernel after changing the parameters
import INPUT_rates

# rate of mutation per fitness per node
INPUT_rates.parameters["mutation_rate"] = 0.00001

# fitness-advantage (multiplicative/logistic) per mutation
# Determines the speed of the competition/replacement process
# Start-value is f=1.0, saturates at 10
INPUT_rates.parameters["strong_fitness_increment"] = 0.4

# fixate the simulation-framework after all parameters are set
INPUT_rates._set_rates()

#%% Simulation with 3D plots at defined sizes
# sizes should not exceed 100.000 vertices for this visualization
import EVAL_over_time_plot_plotly

stop_sizes = [ i*10 for i in [0,2,4,6,8] ]
stop_sizes.extend ( [ i*100 for i in [2,4,6,8] ] )
stop_sizes.extend ( [i*1000 for i in range(1,11) ] )
EVAL_over_time_plot_plotly.sim_and_plot_with_size_frames(stop_sizes)